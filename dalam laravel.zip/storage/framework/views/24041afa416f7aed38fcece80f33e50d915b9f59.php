<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="<?php echo e(route('home')); ?>">diskominfo.bolmongkab.go.id</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer><?php /**PATH C:\xampp\htdocs\disdik.bolmongkab\resources\views/layouts/backend/footer.blade.php ENDPATH**/ ?>