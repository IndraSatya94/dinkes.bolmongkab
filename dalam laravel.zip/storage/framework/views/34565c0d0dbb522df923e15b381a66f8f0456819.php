<header class="page-head" style="position:absolute; left:0; right:0;top:0">
    <!-- RD Navbar Transparent-->
    <div class="rd-navbar-wrap">
        <nav class="rd-navbar rd-navbar-transparent" data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-static" data-stick-up-offset="40" data-lg-auto-height="true" data-auto-height="false" data-md-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-stick-up="true" data-md-focus-on-hover="false">
            <div class="rd-navbar-inner">
                <!-- RD Navbar Panel-->
                <div class="rd-navbar-panel">
                    <!-- RD Navbar Toggle-->
                    <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar, .rd-navbar-nav-wrap"><span></span></button>
                    <h4 class="panel-title d-xl-none">Home</h4>
                </div>
                <div class="rd-navbar-menu-wrap clearfix">
                    <!--Navbar Brand-->
                    <div class="rd-navbar-brand"><a class="d-inline-block" href="<?php echo e(route('home')); ?>">
                            <div class="unit align-items-sm-center unit-lg flex-xl-row unit-spacing-xxs">
                                <div class="unit-left">
                                    <div class="wrap"><img width="170" height="172" src="<?php echo e(Storage::url($university->image??null)); ?>" alt="" />
                                    </div>
                                </div>
                                <div class="unit-body text-xl-left">
                                    <div class="rd-navbar-brand-title">UNIMA</div>
                                    <div class="rd-navbar-brand-slogan text-light"><?php echo e($university->name ?? null); ?></div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="rd-navbar-nav-wrap">
                        <div class="rd-navbar-mobile-scroll">
                            <div class="rd-navbar-mobile-header-wrap">
                                <!--Navbar Brand Mobile-->
                                <div class="rd-navbar-mobile-brand"><a href="<?php echo e(route('home')); ?>"><img width="136" height="138" src="<?php echo e(Storage::url($university->image)); ?>" alt="" /></a></div>
                            </div>
                            <!-- RD Navbar Nav-->
                            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--RD Navbar Mobile Search-->
                            <div class="rd-navbar-search-mobile" id="rd-navbar-search-mobile">
                                <form class="rd-navbar-search-form search-form-icon-right rd-search" action="<?php echo e(route('search')); ?>" method="GET">
                                    <div class="form-wrap">
                                        <label class="form-label" for="rd-navbar-mobile-search-form-input">Search...</label>
                                        <input class="rd-navbar-search-form-input form-input form-input-gray-lightest" id="rd-navbar-mobile-search-form-input" type="text" name="s" autocomplete="off" />
                                    </div>
                                    <button class="icon fa fa-search rd-navbar-search-button" type="submit"></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--RD Navbar Search-->
                    <div class="rd-navbar-search"><a class="rd-navbar-search-toggle mdi" data-rd-navbar-toggle=".rd-navbar-search" href="#"><span></span></a>
                        <form class="rd-navbar-search-form search-form-icon-right rd-search" action="<?php echo e(route('search')); ?>" data-search-live="rd-search-results-live" method="GET">
                            <div class="form-wrap">
                                <label class="form-label" for="rd-navbar-search-form-input">Search</label>
                                <input class="rd-navbar-search-form-input form-input form-input-gray-lightest" id="rd-navbar-search-form-input" type="text" name="s" autocomplete="off" />
                                <div class="rd-search-results-live" id="rd-search-results-live"></div>
                            </div>
                        </form>
                    </div>
                    <!--RD Navbar shop-->
                </div>
            </div>
        </nav>
    </div>
</header><?php /**PATH F:\laragon\www\unima\resources\views/layouts/home/header.blade.php ENDPATH**/ ?>