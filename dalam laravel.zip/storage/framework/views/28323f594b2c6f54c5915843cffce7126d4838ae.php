<nav class="nav-menu d-none d-lg-block">
    <ul>
        <li class="active"><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
        <?php if(isset($menus)): ?>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="drop-down"><a href="#"><?php echo e($menu->name); ?></a>
            <?php if($menu->pages): ?>
            <ul>
                <?php $__currentLoopData = $menu->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page->link): ?>
                <li><a href="<?php echo e($page->link ?? null); ?>"><?php echo e($page->name ?? null); ?></a></li>
                <?php else: ?>
                <li><a href="<?php echo e(route('detail-page', $page->slug)); ?>"><?php echo e($page->name ?? null); ?></a></li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
</nav><!-- .nav-menu --><?php /**PATH C:\xampp\htdocs\disdik.bolmongkab\resources\views/layouts/frontend/nav.blade.php ENDPATH**/ ?>