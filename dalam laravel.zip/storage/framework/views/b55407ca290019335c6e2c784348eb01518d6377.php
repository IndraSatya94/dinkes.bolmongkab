<?php if(isset($modes)): ?>
<?php if($modes->count() > 0): ?>
<div class="offset-top-60">
    <!-- Categories-->
    <h6 class="font-weight-bold">Mode</h6>
    <div class="text-subline"></div>
    <div class="offset-top-20">
        <ul class="list list-marked list-marked-primary">
            <?php $__currentLoopData = $modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('mode', $mode->slug)); ?>"><?php echo e($mode->name ?? null); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php endif; ?>
<?php endif; ?><?php /**PATH F:\laragon\www\unima\resources\views/layouts/mode.blade.php ENDPATH**/ ?>