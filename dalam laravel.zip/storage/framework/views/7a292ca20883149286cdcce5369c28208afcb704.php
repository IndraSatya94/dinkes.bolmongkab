<?php if($categories): ?>
<h3 class="sidebar-title">Category</h3>
<div class="sidebar-item categories">
    <ul>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('category', $category)); ?>"><?php echo e($category->name); ?> <span>(<?php echo e($category->news->count()); ?>)</span></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><!-- End sidebar categories-->
<?php endif; ?><?php /**PATH F:\laragon\www\dispusip\resources\views/layouts/frontend/category.blade.php ENDPATH**/ ?>