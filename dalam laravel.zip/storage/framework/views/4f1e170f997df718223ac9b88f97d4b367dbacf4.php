<div class="card-body">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="form-group">
        <label for="menu">Menu</label>
        <select class="form-control select2" name="menus_id">
            <option value=""></option>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->menus_id == $menu->id): ?> selected <?php endif; ?> value="<?php echo e($menu->id); ?>"><?php echo e($menu->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="group">Group</label>
        <select class="form-control select2" name="group_id">
            <option value=""></option>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->group_id == $group->id): ?> selected <?php endif; ?> value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e(old('name') ?? $item->name); ?>">
    </div>

    <div class="form-group">
        <label>Body</label>
        <textarea class="form-control" rows="3" placeholder="Enter ..." name="body" id="body"><?php echo e(old('body') ?? $item->body); ?></textarea>
    </div>

    <div class="form-group">
        <label for="link">Link</label>
        <input type="text" class="form-control" id="link" name="link" placeholder="link" value="<?php echo e(old('link') ?? $item->link); ?>">
    </div>
    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
    <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" width="200px" />
    <?php endif; ?>
    <div class="form-group">
        <label for="image">Image (JPG,JPEG)</label>
        <div class="input-group">
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="image" name="image">
                <label class="custom-file-label" for="image">Choose file</label>
            </div>
            <div class="input-group-append">
                <span class="input-group-text">Upload</span>
            </div>
        </div>
    </div>
</div>
<!-- /.card-body -->

<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($submit ?? 'Create'); ?></button>
</div><?php /**PATH F:\laragon\www\unima\resources\views/pages/page/partials/form-control.blade.php ENDPATH**/ ?>