
<?php $__env->startSection('page-title', $breadcrumb_title); ?>
<?php $__env->startSection('page', $breadcrumb_h1); ?>
<?php $__env->startSection('page-active', $breadcrumb_title); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="entry entry-single">
    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
    <div class="entry-img">
        <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" alt="" class="img-fluid">
    </div>
    <?php endif; ?>

    <h2 class="entry-title">
        <a href="#"><?php echo e($item->name ?? null); ?></a>
    </h2>

    <div class="entry-meta">
        <ul>
            <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="#"><?php echo e($item->author->name ?? null); ?></a></li>
            <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href="#"><time datetime="2021-03-25"><?php echo e($item->created_at ?? null); ?></time></a></li>
        </ul>
    </div>

    <div class="entry-content">
        <p><?php echo nl2br(e(Str::limit($item->body ?? null, 300))); ?></p>
    </div>

    <div class="entry-footer clearfix">
        <div class="float-left">
            <i class="icofont-folder"></i>
            <ul class="cats">
                <li><a href="<?php echo e(route('category', $item->category)); ?>"><?php echo e($item->category->name ?? null); ?></a></li>
            </ul>
            <?php if($item->tags): ?>
            <i class="icofont-tags"></i>
            <ul class="tags">
                <?php $__currentLoopData = $item->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('tag', $tag)); ?>"><?php echo e($tag->name ?? null); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</article><!-- End blog entry -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app-detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\disdik.bolmongkab\resources\views/pages/detail.blade.php ENDPATH**/ ?>