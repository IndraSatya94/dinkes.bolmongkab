<?php if(isset($university)): ?>
<div class="offset-top-60">
    <!-- Facebook standart widget-->
    <div>
        <div class="fb-root fb-widget">
            <div class="fb-page-responsive">
                <div class="fb-page" data-href="<?php echo e($university->facebook ?? null); ?>" data-tabs="timeline" data-height="220" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                    <div class="fb-xfbml-parse-ignore">
                        <blockquote cite="<?php echo e($university->facebook ?? null); ?>"><a href="<?php echo e($university->facebook ?? null); ?>"><?php echo e($university->name ?? null); ?></a></blockquote>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH F:\laragon\www\unima\resources\views/layouts/fb-widget.blade.php ENDPATH**/ ?>