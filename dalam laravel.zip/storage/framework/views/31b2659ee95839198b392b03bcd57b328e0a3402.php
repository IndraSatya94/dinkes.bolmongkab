<header class="page-head">
    <!-- RD Navbar Transparent-->
    <div class="rd-navbar-wrap">
        <nav class="rd-navbar rd-navbar-default" data-md-device-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-stick-up-offset="210" data-xl-stick-up-offset="85" data-lg-auto-height="true" data-md-layout="rd-navbar-static" data-lg-layout="rd-navbar-static" data-lg-stick-up="true">
            <div class="rd-navbar-inner">
                <!-- RD Navbar Panel-->
                <div class="rd-navbar-panel">
                    <!-- RD Navbar Toggle-->
                    <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar, .rd-navbar-nav-wrap"><span></span></button>
                    <h4 class="panel-title d-lg-none">Pages</h4>
                    <!-- RD Navbar Right Side Toggle-->
                    <button class="rd-navbar-top-panel-toggle d-lg-none" data-rd-navbar-toggle=".rd-navbar-top-panel"><span></span></button>
                    <div class="rd-navbar-top-panel">
                        <div class="rd-navbar-top-panel-left-part">
                            <ul class="list-unstyled">
                                <li>
                                    <div class="unit flex-row align-items-center unit-spacing-xs">
                                        <div class="unit-left"><span class="icon mdi mdi-phone text-middle"></span></div>
                                        <div class="unit-body"><?php echo e($university->phone ?? null); ?>

                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="unit flex-row align-items-center unit-spacing-xs">
                                        <div class="unit-left"><span class="icon mdi mdi-map-marker text-middle"></span></div>
                                        <div class="unit-body"><?php echo e($university->address ?? null); ?></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="unit flex-row align-items-center unit-spacing-xs">
                                        <div class="unit-left"><span class="icon mdi mdi-email-open text-middle"></span></div>
                                        <div class="unit-body"><a href="mailto:#"><?php echo e($university->email ?? null); ?></a></div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="rd-navbar-top-panel-right-part">
                            <div class="rd-navbar-top-panel-left-part">
                                <div class="unit flex-row align-items-center unit-spacing-xs">
                                    <div class="unit-left"><span class="icon mdi mdi-login text-middle"></span></div>
                                    <?php if(auth()->guard()->guest()): ?>
                                    <div class="unit-body"><a href="login-register.html">Login/Register</a></div>
                                    <?php else: ?>
                                    <div class="unit-body"><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"> <?php echo e(__('Logout')); ?></a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="rd-navbar-menu-wrap clearfix">
                    <!--Navbar Brand-->
                    <div class="rd-navbar-brand"><a class="d-inline-block" href="<?php echo e(route('home')); ?>">
                            <div class="unit align-items-sm-center unit-xl flex-column flex-xxl-row unit-spacing-custom">
                                <div class="unit-left"><img width='170' height='172' src='<?php echo e(Storage::url($university->image ?? null)); ?>' alt='' />
                                </div>
                                <div class="unit-body text-xxl-left">
                                    <div class="rd-navbar-brand-title">UNIMA</div>
                                    <div class="rd-navbar-brand-slogan"><?php echo e($university->name ?? null); ?></div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="rd-navbar-nav-wrap">
                        <div class="rd-navbar-mobile-scroll">
                            <div class="rd-navbar-mobile-header-wrap">
                                <!--Navbar Brand Mobile-->
                                <div class="rd-navbar-mobile-brand"><a href="index.html"><img width='136' height='138' src='images/logo-170x172.png' alt='' /></a></div>
                            </div>
                            <!-- RD Navbar Nav-->
                            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--RD Navbar Mobile Search-->
                            <div class="rd-navbar-search-mobile" id="rd-navbar-search-mobile">
                                <form class="rd-navbar-search-form search-form-icon-right rd-search" action="search-results.html" method="GET">
                                    <div class="form-wrap">
                                        <label class="form-label" for="rd-navbar-mobile-search-form-input">Search...</label>
                                        <input class="rd-navbar-search-form-input form-input form-input-gray-lightest" id="rd-navbar-mobile-search-form-input" type="text" name="s" autocomplete="off" />
                                    </div>
                                    <button class="icon fa fa-search rd-navbar-search-button" type="submit"></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--RD Navbar Search-->
                    <div class="rd-navbar-search"><a class="rd-navbar-search-toggle mdi" data-rd-navbar-toggle=".rd-navbar-search" href="#"><span></span></a>
                        <form class="rd-navbar-search-form search-form-icon-right rd-search" action="<?php echo e(route('search')); ?>" data-search-live="rd-search-results-live" method="GET">
                            <div class="form-wrap">
                                <label class="form-label" for="rd-navbar-search-form-input">Search</label>
                                <input class="rd-navbar-search-form-input form-input form-input-gray-lightest" id="rd-navbar-search-form-input" type="text" name="s" autocomplete="off" />
                                <div class="rd-search-results-live" id="rd-search-results-live"></div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </nav>
    </div>
</header><?php /**PATH F:\laragon\www\unima\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>