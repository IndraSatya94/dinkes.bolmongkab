<div class="preloader">
        <div class="preloader-body">
            <div class="cssload-container">
                <div class="cssload-speeding-wheel"></div>
            </div>
            <p>Loading...</p>
        </div>
    </div><?php /**PATH F:\laragon\www\unima\resources\views/layouts/preloader.blade.php ENDPATH**/ ?>