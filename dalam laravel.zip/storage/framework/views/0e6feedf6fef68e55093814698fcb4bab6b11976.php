<div class="card-body">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="form-group">
        <label for="academic">Academic</label>
        <select class="form-control" name="academics_id">
            <option value=""></option>
            <?php $__currentLoopData = $academics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->academics_id == $academic->id): ?> selected <?php endif; ?> value="<?php echo e($academic->id); ?>"><?php echo e($academic->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e(old('name') ?? $item->name); ?>">
    </div>
    <div class="form-group">
        <label>Body</label>
        <textarea class="form-control" rows="3" placeholder="Enter ..." name="body" id="body"><?php echo e(old('body') ?? $item->body); ?></textarea>
    </div>

    <div class="form-group">
        <label>Partime?</label>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="part_time" value="Y" <?php if($item->part_time == 'Y'): ?> ? checked : '' <?php endif; ?>>
            <label class="form-check-label">Yes</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="part_time" value="N" <?php if($item->part_time == 'N'): ?> ? checked : '' <?php endif; ?>>
            <label class="form-check-label">No</label>
        </div>
    </div>
    <div class="form-group">
        <label>Certificate?</label>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="certificate" value="Y" <?php if($item->certificate == 'Y'): ?> ? checked : '' <?php endif; ?>>
            <label class="form-check-label">Yes</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="certificate" value="N" <?php if($item->certificate == 'N'): ?> ? checked : '' <?php endif; ?>>
            <label class="form-check-label">No</label>
        </div>
    </div>
    <div class="form-group">
        <label>Online Course?</label>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="online_course" value="Y" <?php if($item->online_course == 'Y'): ?> ? checked : '' <?php endif; ?>>
            <label class="form-check-label">Yes</label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="online_course" value="N" <?php if($item->online_course == 'N'): ?> ? checked : '' <?php endif; ?>>
            <label class="form-check-label">No</label>
        </div>
    </div>
    <div class="form-group">
        <label for="code">Code</label>
        <input type="text" class="form-control" id="code" name="code" placeholder="code" value="<?php echo e(old('code') ?? $item->code); ?>">
    </div>
    <div class="form-group">
        <label for="next_intake">Next Intake</label>
        <input type="text" class="form-control" id="next_intake" name="next_intake" placeholder="next_intake" value="<?php echo e(old('next_intake') ?? $item->next_intake); ?>">
    </div>
    <div class="form-group">
        <label for="duration">Duration</label>
        <input type="text" class="form-control" id="duration" name="duration" placeholder="duration" value="<?php echo e(old('duration') ?? $item->duration); ?>">
    </div>
    <div class="form-group">
        <label for="mode">Mode</label>
        <select class="form-control" name="mode_id">
            <option value=""></option>
            <?php $__currentLoopData = $modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->mode_id == $mode->id): ?> selected <?php endif; ?> value="<?php echo e($mode->id); ?>"><?php echo e($mode->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
    <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" width="200px" />
    <?php endif; ?>
    <div class="form-group">
        <label for="image">Image(JPG,JPEG)</label>
        <div class="input-group">
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="image" name="image">
                <label class="custom-file-label" for="image">Choose file</label>
            </div>
            <div class="input-group-append">
                <span class="input-group-text">Upload</span>
            </div>
        </div>
    </div>
</div>
<!-- /.card-body -->

<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($submit ?? 'Create'); ?></button>
</div><?php /**PATH F:\laragon\www\unima\resources\views/pages/program/partials/form-control.blade.php ENDPATH**/ ?>