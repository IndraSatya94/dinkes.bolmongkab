
<?php $__env->startSection('page-title', 'Detail Page'); ?>
<?php $__env->startSection('page', 'Page'); ?>
<?php $__env->startSection('page-active', $item->name); ?>
<?php $__env->startSection('content'); ?>
<article class="entry entry-single">
    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
    <div class="entry-img">
        <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" alt="" class="img-fluid">
    </div>
    <?php endif; ?>

    <h2 class="entry-title">
        <a href="#"><?php echo e($item->name ?? null); ?></a>
    </h2>

    <div class="entry-meta">
        <ul>
            <li class="d-flex align-items-center"><i class="icofont-user"></i> <a href="#"><?php echo e($item->author->name ?? null); ?></a></li>
            <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href="#"><time datetime="2021-03-25"><?php echo e($item->created_at ?? null); ?></time></a></li>
        </ul>
    </div>

    <div class="entry-content">
        <p><?php echo nl2br(e($item->body ?? null)); ?></p>
    </div>

    <div class="entry-footer clearfix">
        <div class="float-left">
            <?php if($item->category): ?>
            <i class="icofont-folder"></i>
            <ul class="cats">
                <li><a href="<?php echo e(route('category', $item->category)); ?>"><?php echo e($item->category->name ?? null); ?></a></li>
            </ul>
            <?php endif; ?>
            <?php if($item->tags): ?>
            <i class="icofont-tags"></i>
            <ul class="tags">
                <?php $__currentLoopData = $item->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('tag', $tag)); ?>"><?php echo e($tag->name ?? null); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</article><!-- End blog entry -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app-detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\bkd.bolmongkab\resources\views/pages/page/detail.blade.php ENDPATH**/ ?>