<?php if(isset($archive)): ?>
<div class="offset-top-60">
    <!-- Archive-->
    <h6 class="font-weight-bold">Archive</h6>
    <div class="text-subline"></div>
    <div class="row offset-top-20">
        <div class="col-6">
            <ul class="list list-marked list-marked-primary">
                <li><a href="news-post-page.html">Jun 2019</a></li>
                <li><a href="news-post-page.html">Aug 2019</a></li>
                <li><a href="news-post-page.html">Oct 2019</a></li>
                <li><a href="news-post-page.html">Dec 2019</a></li>
                <li><a href="news-post-page.html">Feb 2018</a></li>
            </ul>
        </div>
        <div class="col-6">
            <ul class="list list-marked list-marked-primary">
                <li><a href="news-post-page.html">Jul 2019</a></li>
                <li><a href="news-post-page.html">Sep 2019</a></li>
                <li><a href="news-post-page.html">Nov 2019</a></li>
                <li><a href="news-post-page.html">Jan 2019</a></li>
                <li><a href="news-post-page.html">Mar 2018</a></li>
            </ul>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH F:\laragon\www\unima\resources\views/layouts/archive.blade.php ENDPATH**/ ?>