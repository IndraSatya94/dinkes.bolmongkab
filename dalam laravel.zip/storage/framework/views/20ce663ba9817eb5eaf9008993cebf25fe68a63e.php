<?php $__env->startPush('addon-style'); ?>
<style>
    .ie-panel {
        display: none;
        background: #212121;
        padding: 10px 0;
        box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
        clear: both;
        text-align: center;
        position: relative;
        z-index: 1;
    }

    html.ie-10 .ie-panel,
    html.lt-ie-10 .ie-panel {
        display: block;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section>
    <!-- Swiper-->
    <div class="swiper-container swiper-slider swiper-slider-3" data-autoplay="true" data-height="100vh" data-loop="true" data-dragable="false" data-min-height="480px" data-slide-effect="true">
        <div class="swiper-wrapper">
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide" data-slide-bg="<?php echo e(Storage::url($slide->image)); ?>" style="background-position: 80% center">
                <div class="swiper-slide-caption header-transparent-slide-caption">
                    <div class="container">
                        <div class="row justify-content-sm-center justify-content-xl-start no-gutters">
                            <div class="col-lg-6 text-lg-left col-sm-10">
                                <div data-caption-animate="fadeInUp" data-caption-delay="100" data-caption-duration="1700">
                                    <h1 class="font-weight-bold"><?php echo e($slide->name); ?></h1>
                                </div>
                                <div class="offset-top-20 offset-xs-top-40 offset-xl-top-60" data-caption-animate="fadeInUp" data-caption-delay="150" data-caption-duration="1700">
                                    <h5 class="text-regular font-default"><?php echo e($slide->body); ?></h5>
                                </div>
                                <div class="offset-top-20 offset-xl-top-40" data-caption-animate="fadeInUp" data-caption-delay="400" data-caption-duration="1700">
                                    <div class="d-xl-inline-block"><a class="btn button-primary btn-ellipse d-none d-xl-inline-block" href="<?php echo e(route('academic')); ?>">Learn More</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Swiper Pagination-->
        <div class="swiper-pagination"></div>
    </div>
</section>
<section class="section breadcrumb-classic context-dark">
    <div class="container">
        <form method="GET" action="<?php echo e(route('search-program')); ?>">
            <div class="row">
                <div class="h6 text-left col-md-12 col-sm-12 col-lg-3">
                    Find your course
                </div>
                <div class="col-3 mb-2 col-md-12 col-sm-12  col-lg-3">
                    <select class="form-input" name="academic">
                        <?php $__currentLoopData = $academics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($academic->id); ?>"><?php echo e($academic->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-3 mb-2 col-md-12 col-sm-12 col-lg-3">
                    <input type="text" class="form-input" name="program" placeholder="Enter course title or keyword" />
                </div>
                <div class="col-3 col-md-12 col-sm-12 col-lg-3">
                    <button class="btn button-primary" type="submit">Search</button>
                </div>
            </div>
        </form>
    </div>
</section>
<!-- A Few Words About the University-->
<section class="section section-xl bg-default m">
    <div class="container">
        <div class="row row-50 text-lg-left justify-content-md-between">
            <div class="col-lg-7 view-animate fadeInRightSm delay-04">
                <div class="img-wrap-2">
                    <figure><a class="icon mdi mdi-play-circle-outline" data-lightgallery="item" href="<?php echo e($university->video_embed ?? null); ?>"></a><img class="img-responsive d-inline-block" src="/template/frontend/images/home-01-620-350.jpg" width="620" height="350" alt=""></figure>
                </div>
            </div>
            <div class="col-lg-5">
                <h2 class="home-headings-custom font-weight-bold view-animate fadeInLeftSm delay-06"><span class="first-word">About</span> Our University</h2>
                <div class="offset-top-35 offset-lg-top-60 view-animate fadeInLeftSm delay-08">
                    <p><?php echo e($university->about ?? null); ?></p>
                </div>
                <div class="offset-top-30 view-animate fadeInLeftSm delay-1"><a class="btn btn-ellipse btn-icon btn-icon-right button-default" href="<?php echo e(route('history')); ?>"><span class="icon fa fa-arrow-right"></span><span>Learn More</span></a></div>
            </div>
        </div>
    </div>
</section>
<!--Our Featured Courses-->
<section class="section bg-madison section-xl text-center">
    <div class="container">
        <h2 class="font-weight-bold text-white view-animate fadeInUpSmall delay-04">Our Programs</h2>
        <div class="offset-top-35 offset-lg-top-60 text-white view-animate fadeInUpSmall delay-06">Our Featured Programs are selected through a rigorous process and uniquely created for each semester.</div>
        <div class="row row-30 justify-content-sm-center offset-top-60 text-md-left">
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 view-animate fadeInRightSm delay-1">
                <article class="post-news bg-default"><a href="#">
                        <?php if(Storage::disk('public')->exists($program->image ?? null)): ?>
                        <img class="img-responsive" src="<?php echo e(Storage::url($program->image ?? null)); ?>" width="370" height="240" alt="">
                        <?php endif; ?>
                    </a>
                    <div class="post-news-body-variant-1">
                        <!-- <div class="post-news-meta">
                            <time class="text-middle font-italic" datetime="2019">June 3, 2019</time>
                        </div> -->
                        <h6><a href="<?php echo e(route('program', $program->slug)); ?>"><?php echo e($program->name ?? null); ?></a></h6>
                        <div class="offset-top-9">
                            <p class="text-base"><?php echo e($program->academic->name ?? null); ?></p>
                        </div>
                        <div class="offset-top-9">
                            <ul class="list-inline list-unstyled list-inline-primary">
                                <?php if($program->part_time && $program->part_time === 'Y'): ?>
                                <li><span class="text-hover-custom icon icon-xxs mdi mdi-timer-sand" data-toggle="tooltip" data-placement="top" title="Part time"></span></li>
                                <?php endif; ?>
                                <?php if($program->certificate && $program->certificate === 'Y'): ?>
                                <li><span class="text-hover-custom icon icon-xxs mdi mdi-star" data-toggle="tooltip" data-placement="top" title="Certified"></span></li>
                                <?php endif; ?>
                                <?php if($program->online_course && $program->online_course === 'Y'): ?>
                                <li><span class="text-hover-custom icon icon-xxs mdi mdi-laptop-chromebook" data-toggle="tooltip" data-placement="top" title="Online Course"></span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="offset-top-35 offset-xl-top-70 view-animate fadeInUpSmall"><a class="btn btn-ellipse button-primary" href="<?php echo e(route('academic')); ?>">View All Programs</a></div>
    </div>
</section>
<!-- Counters-->
<section class="section text-center bg-default">
    <div class="container">
        <div class="row justify-content-sm-center justify-content-md-start offset-top-0">
            <div class="col-sm-10 col-md-7 section-image-aside section-image-aside-right">
                <div class="section-image-aside-img d-none d-md-block view-animate zoomInSmall delay-04" style="background-image: url(<?php echo e(Storage::url($feature->image ?? null)); ?>)"></div>
                <div class="section-image-aside-body section-xl inset-lg-right-70 inset-xl-right-110">
                    <h2 class="home-headings-custom font-weight-bold view-animate fadeInLeftSm delay-04"><span class="first-word">Our</span> Features</h2>
                    <div class="offset-top-35 offset-md-top-60 view-animate fadeInLeftSm delay-06"><?php echo e($feature->description ?? null); ?></div>
                    <div class="text-center text-sm-left">
                        <div class="row row-65 justify-content-sm-center justify-content-lg-start offset-top-65 counters">
                            <div class="col-sm-6 view-animate fadeInLeftSm delay-08">
                                <!-- Counter type 1-->
                                <div class="unit flex-column flex-sm-row unit-responsive-md counter-type-2">
                                    <div class="unit-left"><span class="icon icon-md text-madison mdi mdi-school"></span></div>
                                    <div class="unit-body">
                                        <div class="h3 font-weight-bold text-primary"><span class="counter" data-speed="1300"><?php echo e($feature->awards ?? null); ?></span><span></span></div>
                                        <div class="offset-top-3">
                                            <h6 class="text-black font-accent font-weight-bold">Awards</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 view-animate fadeInLeftSm delay-04">
                                <!-- Counter type 1-->
                                <div class="unit flex-column flex-sm-row unit-responsive-md counter-type-2">
                                    <div class="unit-left"><span class="icon icon-md text-madison mdi mdi-wallet-travel"></span></div>
                                    <div class="unit-body">
                                        <div class="h3 font-weight-bold text-primary"><span class="counter" data-speed="1250"><?php echo e($feature->certified_teachers); ?></span><span>+</span></div>
                                        <div class="offset-top-3">
                                            <h6 class="text-black font-accent font-weight-bold">Certified Teachers</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 view-animate fadeInLeftSm delay-1">
                                <!-- Counter type 1-->
                                <div class="unit flex-column flex-sm-row unit-responsive-md counter-type-2">
                                    <div class="unit-left"><span class="icon icon-md text-madison mdi mdi-domain"></span></div>
                                    <div class="unit-body">
                                        <div class="h3 font-weight-bold text-primary offset-top-5"><span class="counter" data-step="500"><?php echo e($feature->featured_programs ?? null); ?></span></div>
                                        <div class="offset-top-3">
                                            <h6 class="text-black font-accent font-weight-bold">Featured Programs </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 view-animate fadeInLeftSm delay-06">
                                <!-- Counter type 1-->
                                <div class="unit flex-column flex-sm-row unit-responsive-md counter-type-2">
                                    <div class="unit-left"><span class="icon icon-md text-madison mdi mdi-account-multiple-outline"></span></div>
                                    <div class="unit-body">
                                        <div class="h3 font-weight-bold text-primary offset-top-5"><span class="counter" data-step="1500"><?php echo e($feature->students ?? null); ?></span></div>
                                        <div class="offset-top-3">
                                            <h6 class="text-black font-accent font-weight-bold">Students</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section bg-catskill section-xl">
    <div class="container container-wide">
        <h2 class="font-weight-bold">Events</h2>
        <hr class="divider bg-madison">
        <div class="row row-50 offset-top-60 justify-content-sm-center">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-5 col-xxl-3">
                <article class="post-event">
                    <div class="post-event-img-overlay">
                        <?php if(Storage::disk('public')->exists($event->image ?? null)): ?>
                        <img class="img-responsive" src="<?php echo e(Storage::url($event->image ?? null)); ?>" width="420" height="420" alt="">
                        <?php endif; ?>
                        <div class="post-event-overlay context-dark"><a class="btn button-primary" href="<?php echo e(route('apply', $event->slug)); ?>">Book Now</a>
                            <div class="offset-top-20"><a class="btn button-default" href="<?php echo e(route('event', $event->slug)); ?>">Learn More</a></div>
                        </div>
                    </div>
                    <div class="unit unit-lg flex-column flex-xl-row">
                        <div class="unit-left">
                            <div class="post-event-meta text-center">
                                <div class="h3 font-weight-bold d-inline-block d-xl-block"><?php echo e(date('d', strtotime($event->event_date ?? null ))); ?></div>
                                <p class="d-inline-block d-xl-block"><?php echo e(date('F', strtotime($event->event_date ?? null))); ?></p><span class="font-weight-bold d-inline-block d-xl-block inset-left-10 inset-xl-left-0"><?php echo e(date('H:i A', strtotime($event->event_time ?? null))); ?></span>
                            </div>
                        </div>
                        <div class="unit-body">
                            <div class="post-event-body text-xl-left">
                                <h6><a href="<?php echo e(route('event', $event->slug)); ?>"><?php echo e($event->name ?? null); ?></a></h6>
                                <ul class="list-inline list-inline-xs">
                                    <li><a href="<?php echo e(route('detail-lecture', $event->lecture->slug)); ?>"><span class="icon icon-xxs mdi mdi-account-outline text-middle"></span><span class="inset-left-10 text-dark text-middle"><?php echo e($event->lecture->name); ?></span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="offset-top-50 offset-lg-top-56"><a class="btn btn-ellipse btn-icon btn-icon-right button-primary" href="<?php echo e(route('events')); ?>"><span class="icon fa fa-arrow-right"></span><span>View Event Calendar</span></a></div>
    </div>
</section>
<!-- Testimonials-->
<section class="section context-dark parallax-container position-relative" data-parallax-img="/template/frontend/images/parallax-03.jpg">
    <div class="parallax-content">
        <div class="container">
            <div class="owl-carousel owl-carousel-default carousel-type-1 owl-carousel-nav-xl" data-items="1" data-md-items="2" data-nav="true" data-dots="true" data-margin="30" data-loop="true" data-nav-class="[&quot;owl-prev fa fa-angle-left&quot;, &quot;owl-next fa fa-angle-right&quot;]">
                <?php $__currentLoopData = $testimonies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-xl">
                    <div class="quote-classic-boxed text-left">
                        <div class="quote-body">
                            <q><?php echo e($testimony->quote ?? null); ?></q>
                            <div class="offset-top-30 text-left">
                                <div class="unit flex-row">
                                    <div class="unit-left">
                                        <?php if(Storage::disk('public')->exists($testimony->image ?? null)): ?>
                                        <img class="img-responsive d-inline-block rounded-circle" src="<?php echo e(Storage::url($testimony->image ?? null)); ?>" width="80" height="80" alt="">
                                        <?php endif; ?>
                                    </div>
                                    <div class="unit-body">
                                        <cite class="font-accent"><?php echo e($testimony->name); ?></cite>
                                        <div class="offset-top-5">
                                            <p class="text-dark font-italic"><?php echo e($testimony->graduate); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Latest news-->
<section class="section bg-catskill section-xl">
    <div class="container container-wide">
        <h2 class="home-headings-custom font-weight-bold view-animate fadeInUpSmall delay-06">Latest News</h2>
        <div class="row row-30 offset-top-60 text-left justify-content-sm-center">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-3">
                <article class="post-news post-news-mod-1 view-animate fadeInLeftSm delay-04"><a href="#">
                        <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
                        <img class="img-responsive img-fullwidth" src="<?php echo e(Storage::url($item->image ?? null)); ?>" width="370" height="240" alt="">
                        <?php endif; ?>
                    </a>
                    <div class="post-news-body">
                        <h6><a href="<?php echo e(route('detail-news', $item->slug )); ?>"><?php echo e($item->name ?? null); ?></a></h6>
                        <div class="offset-top-20">
                            <p><?php echo e(Str::limit($item->body ?? null, 100)); ?></p>
                        </div>
                        <div class="post-news-meta offset-top-20"><span class="icon icon-xs mdi mdi-calendar-clock text-middle text-madison"></span><span class="text-middle inset-left-10 font-italic text-black"><?php echo e($item->created_at->diffForHumans() ?? null); ?></span></div>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="offset-top-50 view-animate fadeInUpSmall"><a class="btn btn-ellipse button-primary" href="<?php echo e(route('news')); ?>">View All News Posts</a></div>
    </div>
</section>
<!-- Gallery Simple-->
<!-- Gallery-->
<section class="section">
    <div class="owl-carousel flickr owl-carousel-fullheight" data-items="2" data-sm-items="2" data-autoplay="true" data-md-items="4" data-xxl-items="6" data-nav="false" data-dots="false" data-mouse-drag="true" data-lightgallery="group" data-stage-padding="0" data-xl-stage-padding="0">
        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="thumbnail-default" data-lightgallery="item" href="<?php echo e(Storage::url($gallery->image ?? null)); ?>">
            <?php if(Storage::disk('public')->exists($gallery->image ?? null)): ?>
            <img width="320" height="320" data-title="alt" src="<?php echo e(Storage::url($gallery->image ?? null)); ?>" alt="">
            <?php endif; ?>
            <span class="icon fa fa-search-plus"></span></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\unima\resources\views/home.blade.php ENDPATH**/ ?>