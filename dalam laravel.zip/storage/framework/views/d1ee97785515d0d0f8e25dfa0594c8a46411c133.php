
<?php $__env->startPush('addon-script'); ?>
<!-- bs-custom-file-input -->
<script src="/template/backend/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<script>
    $(function() {
        bsCustomFileInput.init();
    });

    var is_admin = '<?php echo e(auth()->user()->is_admin); ?>';
    if (is_admin == 'N') {
        $('.fg-role').hide();
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Change User</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <?php echo Form::model($item, ['method' => 'PATCH','route' => ['user.update', $item->id]]); ?>

                    <?php echo method_field('PUT'); ?>
                    <!-- <?php echo csrf_field(); ?> -->
                    <?php echo $__env->make('pages.user.partials.form-control', ['submit' => 'Update'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\dispusip\resources\views/pages/user/edit.blade.php ENDPATH**/ ?>