<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-info">
                        <img src="<?php echo e(Storage::url($profile->image ?? null )); ?>" width="64px" />
                        <h3><?php echo e($profile->name ?? null); ?></h3>
                        <strong>Sosial Media</strong><br>
                        <div class="social-links mt-3">
                            <a href="<?php echo e($profile->twitter ?? null); ?>" class="twitter"><i class="bx bxl-twitter"></i></a>
                            <a href="<?php echo e($profile->facebook ?? null); ?>" class="facebook"><i class="bx bxl-facebook"></i></a>
                            <a href="<?php echo e($profile->instagram ?? null); ?>" class="instagram"><i class="bx bxl-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <?php if(isset($bottomMenus)): ?>
                <?php $__currentLoopData = $bottomMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bottomMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 footer-links">
                    <h4><?php echo e($bottomMenu->name ?? null); ?></h4>
                    <?php if($bottomMenu->pages): ?>
                    <ul>
                        <?php $__currentLoopData = $bottomMenu->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page->link): ?>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e($page->link); ?>"><?php echo e($page->name ?? null); ?></a></li>
                        <?php else: ?>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('detail-page', $page->slug)); ?>"><?php echo e($page->name ?? null); ?></a></li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright 2021 <strong><span><?php echo e($profile->name ?? null); ?></span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Powered by <a href="https://diskominfo.bolmongkab.go.id/">e-Government</a>
        </div>
    </div>
</footer><!-- End Footer --><?php /**PATH C:\xampp\htdocs\dinkes.bolmongkab\resources\views/layouts/frontend/footer.blade.php ENDPATH**/ ?>