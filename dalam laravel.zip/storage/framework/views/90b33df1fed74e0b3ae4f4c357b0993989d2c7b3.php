<ul class="rd-navbar-nav">
    <li class="active"><a href="<?php echo e(route('home')); ?>">Home</a>
    </li>
    <?php if(isset($menus)): ?>
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($menu->mega_menu == 'N'): ?>
    <li><a href="#"><?php echo e($menu->name ?? null); ?></a>
        <ul class="rd-navbar-dropdown">
            <?php $__currentLoopData = $menu->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page->link): ?>
            <li><a href="<?php echo e($page->link); ?>"><?php echo e($page->name ?? null); ?></a>
            </li>
            <?php else: ?>
            <li><a href="<?php echo e(route('detail-page', $page->slug)); ?>"><?php echo e($page->name ?? null); ?></a>
            </li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
    <?php else: ?>
    <li><a href="#"><?php echo e($menu->name ?? null); ?></a>
        <div class="rd-navbar-megamenu">
            <div class="row section-relative">
                <?php if(count($groups) > 0): ?>
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($group->pages) > 0): ?>
                <ul class="col-xl-3">
                    <li>
                        <h6><?php echo e($group->name ?? null); ?></h6>
                        <ul class="list-unstyled offset-lg-top-20">
                            <?php $__currentLoopData = $group->pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php if($page->link): ?>
                                <a href="<?php echo e($page->link); ?>" target="_blank"><?php echo e($page->name ?? null); ?></a>
                                <?php else: ?>
                                <a href="<?php echo e(route('detail-page', $page->slug)); ?>"><?php echo e($page->name ?? null); ?></a>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                </ul>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </li>

    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(isset($categories)): ?>
    <?php if($categories): ?>
    <li><a href="<?php echo e(route('news')); ?>">News</a>
        <ul class="rd-navbar-dropdown">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('category', $category->slug)); ?>"><?php echo e($category->name ?? null); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
    <?php endif; ?>
    <?php endif; ?>

</ul><?php /**PATH F:\laragon\www\unima\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>