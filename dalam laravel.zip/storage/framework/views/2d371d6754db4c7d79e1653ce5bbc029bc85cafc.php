<div class="card-body">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e(old('name') ?? $item->name); ?>">
    </div>
    <div class="form-group">
        <label for="name">Permission</label><br />
        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions ?? []) ? true : false, array('class' => 'name'))); ?>

            <?php echo e($value->name); ?></label>
        <br />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- /.card-body -->

<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($submit ?? 'Create'); ?></button>
</div><?php /**PATH F:\laragon\www\bkd.bolmongkab\resources\views/pages/roles/partials/form-control.blade.php ENDPATH**/ ?>