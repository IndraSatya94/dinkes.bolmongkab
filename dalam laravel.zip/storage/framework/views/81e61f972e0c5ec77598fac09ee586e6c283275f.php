<section id="more" class="services">
    <div class="container">

        <div class="section-title">
            <h2>Services</h2>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="icon-box d-flex align-items-center">
                    <img src="/template/frontend/assets/img/undraw_book_lover_mkck.svg" width="100" alt="">
                    <h4><a href="#">Library</a></h4>
                </div>
            </div>
            <div class="col-md-6 mt-4 mt-md-0">
                <div class="icon-box d-flex align-items-center">
                    <img src="/template/frontend/assets/img/undraw_book_lover_mkck.svg" width="100" alt="">
                    <h4><a href="#">Arsip</a></h4>
                </div>
            </div>
        </div>

    </div>
</section><?php /**PATH C:\xampp\htdocs\disdik.bolmongkab\resources\views/layouts/frontend/service.blade.php ENDPATH**/ ?>