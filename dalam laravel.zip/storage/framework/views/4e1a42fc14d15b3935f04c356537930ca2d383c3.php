
<?php $__env->startPush('addon-style'); ?>
<style>
    .ie-panel {
        display: none;
        background: #212121;
        padding: 10px 0;
        box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
        clear: both;
        text-align: center;
        position: relative;
        z-index: 1;
    }

    html.ie-10 .ie-panel,
    html.lt-ie-10 .ie-panel {
        display: block;
    }
</style>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div id="fb-root"></div>
<!-- Latest news-->
<section class="section section-xl">
    <div class="container">
        <div class="row row-85 justify-content-sm-center">
            <div class="col-md-8 col-lg-8 text-lg-left">
                <h2 class="font-weight-bold">
                    <?php echo e($item->name ?? null); ?>

                </h2>
                <hr class="divider bg-madison divider-lg-0">
                <div class="offset-lg-top-47 offset-top-20">
                    <ul class="post-news-meta list list-inline list-inline-xl">
                        <?php if($item->created_at && !$item->code): ?>
                        <li><span class="icon icon-xs mdi mdi-calendar-clock text-middle text-madison"></span><span class="text-middle inset-left-10 font-italic text-black"><?php echo e($item->created_at->diffForHumans() ?? null); ?></span></li>
                        <?php endif; ?>
                        <?php if($item->code): ?>
                        <li>Code : <span class="text-middle inset-left-10 font-italic text-black"><?php echo e($item->code ?? null); ?></span></li>
                        <?php endif; ?>
                        <?php if($item->next_intake): ?>
                        <li>Next Intake : <span class="text-middle inset-left-10 font-italic text-black"><?php echo e($item->next_intake ?? null); ?></span></li>
                        <?php endif; ?>
                        <?php if($item->duration): ?>
                        <li>Duration : <span class="text-middle inset-left-10 font-italic text-black"><?php echo e($item->duration ?? null); ?></span></li>
                        <?php endif; ?>
                        <?php if($item->mode): ?>
                        <li>Mode : <span class="text-middle inset-left-10 font-italic text-black"><?php echo e($item->mode->name ?? null); ?></span></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="offset-top-30">
                    <?php if(Storage::disk('public')->exists($item->iamge ?? null)): ?>
                    <img class="img-responsive" src="<?php echo e(Storage::url($item->image ?? null)); ?>" width="770" height="500" alt="">
                    <?php endif; ?>
                    <div class="offset-top-30">
                        <?php echo nl2br($item->body) ?? null; ?>

                    </div>
                </div>
                <?php if($item->content_groups): ?>

                <div class="tabs-custom tabs-horizontal tabs-line">
                    <!--Nav tabs-->
                    <ul class="nav nav-tabs">
                        <?php $__currentLoopData = $item->content_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $content_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link <?php echo e($i == 0 ? 'active' : ''); ?>" href="#tabs-<?php echo e($content_group->id); ?>" data-toggle="tab"><?php echo e($content_group->content->name ?? null); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!--Tab panes-->
                    <div class="tab-content">
                        <?php $__currentLoopData = $item->content_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $content_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="<?php echo e($i==0 ? 'tab-pane fade show active' : 'tab-pane fade'); ?>" id="tabs-<?php echo e($content_group->id); ?>">
                            <?php if(Storage::disk('public')->exists($content_group->image ?? null)): ?>
                            <img class="img-responsive" src="<?php echo e(Storage::url($content_group->image ?? null)); ?>" width="770" height="500" alt="">
                            <?php endif; ?>
                            <p><?php echo e($content_group->body ?? null); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-4 text-left col-sm-8">
                <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\unima\resources\views/pages/page/detail.blade.php ENDPATH**/ ?>