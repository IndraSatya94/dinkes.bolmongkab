<?php if(isset($banner)): ?>
<div class="offset-top-60 text-center">
    <a class="d-block" href="<?php echo e($banner->link); ?>">
        <img class="img-responsive d-inline-block" src="<?php echo e(Storage::url($banner->image ?? null)); ?>" width="340" height="500" alt="">
    </a>
</div>
<?php endif; ?><?php /**PATH F:\laragon\www\unima\resources\views/layouts/banner.blade.php ENDPATH**/ ?>