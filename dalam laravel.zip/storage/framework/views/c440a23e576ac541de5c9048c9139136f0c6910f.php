<?php if($tags): ?>
<h3 class="sidebar-title">Tags</h3>
<div class="sidebar-item tags">
    <ul>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('tag', $tag)); ?>"><?php echo e($tag->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><!-- End sidebar tags-->
<?php endif; ?><?php /**PATH C:\xampp\htdocs\disdik.bolmongkab\resources\views/layouts/frontend/tag.blade.php ENDPATH**/ ?>