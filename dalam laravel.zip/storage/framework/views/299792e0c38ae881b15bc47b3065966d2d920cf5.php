<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

        <div class="d-flex justify-content-between align-items-center">
            <h2><?php echo $__env->yieldContent('page-title'); ?></h2>
            <ol>
                <li><a href="#"><?php echo $__env->yieldContent('page'); ?></a></li>
                <li><?php echo $__env->yieldContent('page-active'); ?></li>
            </ol>
        </div>

    </div>
</section><!-- End Breadcrumbs --><?php /**PATH F:\laragon\www\dispusip\resources\views/layouts/frontend/breadcrumbs.blade.php ENDPATH**/ ?>