<div class="card-body">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="form-group">
        <label for="event">Event</label>
        <select class="form-control select2" name="events_id" style="width: 100%;">
            <option value="" selected disabled>Choose One</option>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->events_id == $event->id || old('event_id') == $event->id): ?> selected <?php endif; ?> value="<?php echo e($event->id); ?>"><?php echo e($event->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label>How to apply?</label>
        <textarea class="form-control" rows="3" placeholder="Enter ..." name="body" id="body"><?php echo e(old('body') ?? $item->body); ?></textarea>
    </div>
    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
    <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" width="200px" />
    <?php endif; ?>
    <div class="form-group">
        <label for="image">Image(JPEG,JPG) 370x370</label>
        <div class="input-group">
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="image" name="image">
                <label class="custom-file-label" for="image">Choose file</label>
            </div>
            <div class="input-group-append">
                <span class="input-group-text">Upload</span>
            </div>
        </div>
    </div>
</div>
<!-- /.card-body -->

<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($submit ?? 'Create'); ?></button>
</div><?php /**PATH F:\laragon\www\unima\resources\views/pages/how_to_apply/partials/form-control.blade.php ENDPATH**/ ?>