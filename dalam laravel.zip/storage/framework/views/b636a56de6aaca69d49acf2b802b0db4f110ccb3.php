<?php if(isset($galleries)): ?>
<div class="offset-top-60">
    <!-- Flickr Feed-->
    <h6 class="font-weight-bold">Gallery</h6>
    <div class="text-subline"></div>
    <div class="offset-top-20 text-left">
        <div class="flickr widget-flickrfeed" data-lightgallery="group">
            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="thumbnail-default" style="float: left;" data-lightgallery="item" href="<?php echo e(Storage::url($gallery->image ?? null )); ?>">
                <img width="170" height="170" data-title="alt" src="<?php echo e(Storage::url($gallery->image ?? null )); ?>" alt="">
                <span class="icon fa fa-search-plus"></span>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<div style="display: block; clear:both;"></div>
<?php endif; ?><?php /**PATH F:\laragon\www\unima\resources\views/layouts/gallery.blade.php ENDPATH**/ ?>