<?php if(isset($recents)): ?>
<div class="offset-top-60">
    <!--Recent posts-->
    <h6 class="font-weight-bold">Recent News</h6>
    <div class="text-subline"></div>
    <div class="text-left">
        <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="offset-top-20">
            <article class="widget-post">
                <h6 class="font-weight-bold text-primary"><a href="<?php echo e(route('detail-news', $recent->slug)); ?>"><?php echo e($recent->name ?? null); ?></a></h6>
                <p class="text-dark"><?php echo e($recent->created_at->diffForHumans() ?? null); ?> by <?php echo e($recent->author->name ?? null); ?></p>
            </article>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?><?php /**PATH F:\laragon\www\unima\resources\views/layouts/recent.blade.php ENDPATH**/ ?>