<?php if(isset($tags)): ?>
<div class="offset-top-60">
    <h6 class="font-weight-bold">Tags</h6>
    <div class="text-subline"></div>
    <div class="offset-top-20">
        <div class="tags-list group group-sm d-inline-block text-middle">
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="btn btn-xs button-primary font-italic" href="<?php echo e(route('tag', $tag->slug)); ?>"><?php echo e($tag->name ?? null); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH F:\laragon\www\unima\resources\views/layouts/tags.blade.php ENDPATH**/ ?>