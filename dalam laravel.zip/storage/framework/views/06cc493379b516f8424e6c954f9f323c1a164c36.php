<!DOCTYPE html>
<html class="wide wow-animation scrollTo" lang="en">

<head>
  <!-- Site Title-->
  <title><?php echo e($title ?? null); ?></title>
  <meta charset="utf-8">
  <meta name="format-detection" content="telephone=no">
  <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="keywords" content="intense web design multipurpose template">
  <meta name="date" content="Dec 26">
  <link rel="icon" href="/template/frontend/images/favicon.ico" type="image/x-icon">
  <!-- Stylesheets-->
  <?php echo $__env->yieldPushContent('prepend-style'); ?>
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans:400,300italic,300,400italic,600,700%7CMerriweather:400,300,300italic,400italic,700,700italic">
  <link rel="stylesheet" href="/template/frontend/css/bootstrap.css">
  <link rel="stylesheet" href="/template/frontend/css/fonts.css">
  <link rel="stylesheet" href="/template/frontend/css/style.css">
  <?php echo $__env->yieldPushContent('addon-style'); ?>
</head>

<body>
  <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="/template/frontend/images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
  <?php echo $__env->make('layouts.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Page-->
  <div class="page text-center">
    <!-- Page Header-->
    <?php echo $__env->make('layouts.home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Corporate footer-->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <!-- Global Mailform Output-->
  <div class="snackbars" id="form-output-global"></div>
  <!-- Java script-->
  <?php echo $__env->yieldPushContent('preload-script'); ?>
  <script src="/template/frontend/js/core.min.js"></script>
  <script src="/template/frontend/js/script.js"></script>
  <?php echo $__env->yieldPushContent('addon-script'); ?>
</body>

</html><?php /**PATH F:\laragon\www\unima\resources\views/layouts/home/app.blade.php ENDPATH**/ ?>