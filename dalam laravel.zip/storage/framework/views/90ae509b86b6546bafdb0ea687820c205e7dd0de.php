<div class="card-body">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('success')); ?>

    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="form-group fg-program">
        <label for="program">Program</label>
        <select class="form-control select2" name="program_id" style="width: 100%;">
            <option value="" selected disabled>Choose One</option>
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->program_id == $program->id || old('program_id') == $program->id): ?> selected <?php endif; ?> value="<?php echo e($program->id); ?>"><?php echo e($program->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="content">Content</label>
        <select class="form-control select2" name="content_id" style="width: 100%;">
            <option value="" selected disabled>Choose One</option>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($item->content_id == $content->id || old('content_id') == $content->id): ?> selected <?php endif; ?> value="<?php echo e($content->id); ?>"><?php echo e($content->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e(old('name') ?? $item->name); ?>">
    </div>
    <div class="form-group">
        <label>Body</label>
        <textarea class="form-control" rows="3" placeholder="Enter ..." name="body" id="body"><?php echo e(old('body') ?? $item->body); ?></textarea>
    </div>
    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
    <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" width="200px" />
    <?php endif; ?>
    <div class="form-group">
        <label for="image">Image(JPG,JPEG)</label>
        <div class="input-group">
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="image" name="image">
                <label class="custom-file-label" for="image">Choose file</label>
            </div>
            <div class="input-group-append">
                <span class="input-group-text">Upload</span>
            </div>
        </div>
    </div>
</div>
<!-- /.card-body -->

<div class="card-footer">
    <a href="<?php echo e(route('contentgroup.index')); ?>" class="btn btn-info">Back</a>
    <button type="submit" class="btn btn-primary"><?php echo e($submit ?? 'Create'); ?></button>
</div><?php /**PATH F:\laragon\www\unima\resources\views/pages/contentgroup/partials/form-control.blade.php ENDPATH**/ ?>