
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-text-width"></i>
                Contact
            </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">

            <dl class="row">
                <dt class="col-sm-4">Name</dt>
                <dd class="col-sm-8"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></dd>
                <dt class="col-sm-4">Phone</dt>
                <dd class="col-sm-8"><?php echo e($item->phone); ?></dd>
                <dt class="col-sm-4">Email</dt>
                <dd class="col-sm-8"><a href="mailto:<?php echo e($item->email); ?>"><?php echo e($item->email); ?></a></dd>
                <dt class="col-sm-4">Message</dt>
                <dd class="col-sm-8"><?php echo e($item->message); ?></dd>
            </dl>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\unima\resources\views/pages/contact/show.blade.php ENDPATH**/ ?>