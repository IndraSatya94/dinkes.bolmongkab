<?php $__env->startSection('content'); ?>
 <!-- ======= About Section ======= -->
 <section id="about" class="about">
          <div class="container">
    
          <div class="section-title">
            <h2>Tentang</h2>
        </div>
            
            <div class="section-image">
            </div>

            <div class="row">
              <div class="col-xl-6 col-lg-7" data-aos="fade-right">
                <img src="template/frontend/assets/img/disdik1.jpg" class="img-fluid" alt="">
              </div>
              <div class="col-xl-6 col-lg-5 pt-5 pt-lg-0">
                <h2 data-aos="fade-up">DISDIK Bolmong</h2>
                <hr>
                <p data-aos="fade-up">
                  Dinas Pendidikan Kabupaten Bolaang Mongondow adalah SKPD yang memiliki tanggung jawab dalam merencanakan, melaksanakan, mengawasi, mengevaluasi, dan membuat pertanggungjawaban tentang pelaksanaan tugas bidang pendidikan di lingkungan Pemerintahan Kabupaten Bolaang Mongondow. Sebagai sebuah organisasi, tercapainya visi dan misi Dinas Pendidikan Kabupaten Bolaang Mongondow ditentukan oleh kerjasama antara seluruh sistem organisasi, bidang, lini, staf, dan unit pelaksana teknis yang telah dibentuk berdasarkan tugas, pokok, dan fungsinya masing-masing.
                </p>
              </div>
            </div>
    
          </div>
        </section><!-- End About Section -->
<section id="blog" class="blog">
    <div class="container">

        <div class="section-title">
            <h2>News</h2>
        </div>

        <div class="row">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4  col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                <article class="entry">
                    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
                    <div class="entry-img">
                        <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" alt="" class="img-fluid" style="height:250px; width:100%; object-fit:cover; object-position:center;">
                    </div>
                    <?php endif; ?>

                    <h2 class="entry-title">
                        <a href="<?php echo e(route('detail-news', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                    </h2>

                    <div class="entry-meta">
                        <ul>
                            <li class="d-flex align-items-center"><i class="icofont-user"></i> <?php echo e($item->author->name); ?></li>
                            <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <time datetime="2021-03-25"><?php echo e($item->created_at->diffForHumans()); ?></time></li>
                        </ul>
                    </div>

                    <div class="entry-content">
                        <p>
                            <?php echo e(Str::limit($item->body ?? null, 100)); ?>

                        </p>
                        <div class="read-more">
                            <a href="<?php echo e(route('detail-news', $item->slug)); ?>">Selengkapnya</a>
                        </div>
                    </div>

                </article><!-- End blog entry -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section><!-- End Blog Section -->

<section id="more" class="services">
    <div class="container">

        <div class="row">
            <?php if($information->count() > 0): ?>
            <div class="col">
                <div class="section-title">
                    <h2>Information</h2>
                </div>
                <?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="icon-box d-flex align-items-center">
                            <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
                            <img src="<?php echo e(Storage::url($item->image ?? null )); ?>" width="100" alt="">
                            <?php endif; ?>
                            <h4><a href="<?php echo e(route('information', $item->slug)); ?>"><?php echo e($item->name ?? null); ?></a></h4>
                            <p class="text-secondary">Event Date : <?php echo e($item->event_date ?? null); ?> | Event Time : <?php echo e($item->event_time ?? null); ?></p>
                            <p><?php echo e(Str::limit($item->body ?? null, 100)); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <?php if($events->count() > 0): ?>
            <div class="col">
                <div class="section-title">
                    <!-- <p></p> -->
                    <h2>Events</h2>
                </div>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col">
                        <div class="icon-box align-items-center">
                            <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
                            <img src="<?php echo e(Storage::url($item->image ?? null )); ?>" width="100" alt="">
                            <?php endif; ?>
                            <h4><a href="<?php echo e(route('event', $item)); ?>"><?php echo e($item->name ?? null); ?></a></h4>
                            <p class="text-secondary">Event Date : <?php echo e($item->event_date ?? null); ?> | Event Time : <?php echo e($item->event_time ?? null); ?></p>
                            <p><?php echo e(Str::limit($item->body ?? null, 100)); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\disdik.bolmongkab\resources\views/home.blade.php ENDPATH**/ ?>