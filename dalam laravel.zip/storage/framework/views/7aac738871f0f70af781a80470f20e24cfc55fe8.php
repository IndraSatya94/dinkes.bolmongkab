<aside class="inset-lg-left-30">
    <h6 class="font-weight-bold">Search</h6>
    <div class="text-subline"></div>
    <div class="offset-top-30">
        <!-- RD Search Form-->
        <form class="form-search rd-search form-search-widget rd-form-inline rd-form-inline-custom" action="<?php echo e(route('search')); ?>" method="GET">
            <div class="form-wrap">
                <div class="input-group">
                    <input class="form-search-input  form-input" type="text" name="s" autocomplete="off"><span class="input-group-btn">
                        <button class="btn button-primary" type="submit"><span class="icon fa fa-search"></span></button></span>
                </div>
            </div>
        </form>
    </div>
    <?php echo $__env->make('layouts.archive', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.mode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.academic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.fb-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.recent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</aside><?php /**PATH F:\laragon\www\unima\resources\views/layouts/aside.blade.php ENDPATH**/ ?>