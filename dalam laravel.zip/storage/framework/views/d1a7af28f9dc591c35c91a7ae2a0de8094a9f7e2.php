
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-text-width"></i>
                <?php echo e($item->events->name); ?>

            </h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-4">Lecture</dt>
                <dd class="col-sm-8"><?php echo e($item->events->lecture->name); ?></dd>
                <dt class="col-sm-4">Event</dt>
                <dd class="col-sm-8"><?php echo e($item->events->name); ?></dd>
                <dt class="col-sm-4">Description</dt>
                <dd class="col-sm-8"><?php echo e($item->events->body); ?></dd>
                <dt class="col-sm-4">Date</dt>
                <dd class="col-sm-8"><?php echo e($item->events->event_date); ?></dd>
                <dt class="col-sm-4">Time</dt>
                <dd class="col-sm-8"><?php echo e($item->events->event_time); ?></dd>
                <dt class="col-sm-4">Location</dt>
                <dd class="col-sm-8"><?php echo e($item->events->location); ?></dd>
            </dl>
            <br />
            <dl class="row">
                <dt class="col-sm-4">Name</dt>
                <dd class="col-sm-8"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></dd>
                <dt class="col-sm-4">Phone</dt>
                <dd class="col-sm-8"><?php echo e($item->phone); ?></dd>
                <dt class="col-sm-4">Email</dt>
                <dd class="col-sm-8"><?php echo e($item->email); ?></dd>
                <dt class="col-sm-4">Level</dt>
                <dd class="col-sm-8"><?php echo e($item->level); ?></dd>
                <dt class="col-sm-4">File</dt>
                <dd class="col-sm-8"><a href="<?php echo e(Storage::url($item->file_apply)); ?>"><?php echo e($item->file_apply); ?></dd>
            </dl>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\unima\resources\views/pages/apply/show.blade.php ENDPATH**/ ?>