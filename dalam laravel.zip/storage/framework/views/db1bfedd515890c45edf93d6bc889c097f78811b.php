<?php $__env->startSection('content'); ?>
<section id="features" class="padd-section text-center">

      <div class="container" data-aos="fade-up">

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-md-6 col-lg-4">
            <div class="feature-block">
              <img src="template/frontend/assets/img/svg/germas.svg" alt="img"  width="100" height="50">
              <h4>GERMAS</h4>
              <p>Gerakan Masyarakat Hidup Sehat adalah suatu tindakan yang sistematis dan terencana yang dilakukan secara bersama-sama oleh seluruh komponen bangsa dengan kesadaran, kemauan dan kemampuan berperilaku sehat untuk meningkatkan kualitas hidup.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="feature-block">
              <img src="template/frontend/assets/img/svg/bpjs.svg" alt="img"  width="100" height="50">
              <h4>BPJS Kesehatan</h4>
              <p>BPJS Kesehatan merupakan Badan Hukum Publik yang bertanggung jawab langsung kepada Presiden dan memiliki tugas untuk menyelenggarakan jaminan Kesehatan Nasional bagi seluruh rakyat Indonesia</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-4">
            <div class="feature-block">
              <img src="template/frontend/assets/img/svg/kemkes.svg" alt="img"  width="100" height="50">
              <h4>Kementerian Kesehatan</h4>
              <p>Kementerian Kesehatan RI mempunyai tugas membantu Presiden dalam menyelenggarakan sebagian urusan pemerintahan di bidang kesehatan. Berdasarkan Permenkes 64 Tahun 2016, pasal 3 dalam pelaksanaan tugas.</p>
            </div>
          </div>

        </div>
      </div>
    </section><!-- End Features Section -->
<section id="blog" class="blog">
    <div class="container">

        <div class="section-title">
            <h2>News</h2>
        </div>

        <div class="row">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4  col-md-6 d-flex align-items-stretch" data-aos="fade-up">
                <article class="entry">
                    <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
                    <div class="entry-img">
                        <img src="<?php echo e(Storage::url($item->image ?? null)); ?>" alt="" class="img-fluid" style="height:250px; width:100%; object-fit:cover; object-position:center;">
                    </div>
                    <?php endif; ?>

                    <h2 class="entry-title">
                        <a href="<?php echo e(route('detail-news', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                    </h2>

                    <div class="entry-meta">
                        <ul>
                            <li class="d-flex align-items-center"><i class="icofont-user"></i> <?php echo e($item->author->name); ?></li>
                            <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <time datetime="2021-03-25"><?php echo e($item->created_at->diffForHumans()); ?></time></li>
                        </ul>
                    </div>

                    <div class="entry-content">
                        <p>
                            <?php echo e(Str::limit($item->body ?? null, 100)); ?>

                        </p>
                        <div class="read-more">
                            <a href="<?php echo e(route('detail-news', $item->slug)); ?>">Selengkapnya</a>
                        </div>
                    </div>

                </article><!-- End blog entry -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section><!-- End Blog Section -->

<section id="more" class="services">
    <div class="container">

        <div class="row">
            <?php if($information->count() > 0): ?>
            <div class="col">
                <div class="section-title">
                    <h2>Information</h2>
                </div>
                <?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="icon-box d-flex align-items-center">
                            <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
                            <img src="<?php echo e(Storage::url($item->image ?? null )); ?>" width="100" alt="">
                            <?php endif; ?>
                            <h4><a href="<?php echo e(route('information', $item->slug)); ?>"><?php echo e($item->name ?? null); ?></a></h4>
                            <p class="text-secondary">Event Date : <?php echo e($item->event_date ?? null); ?> | Event Time : <?php echo e($item->event_time ?? null); ?></p>
                            <p><?php echo e(Str::limit($item->body ?? null, 100)); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <?php if($events->count() > 0): ?>
            <div class="col">
                <div class="section-title">
                    <!-- <p></p> -->
                    <h2>Events</h2>
                </div>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col">
                        <div class="icon-box align-items-center">
                            <?php if(Storage::disk('public')->exists($item->image ?? null)): ?>
                            <img src="<?php echo e(Storage::url($item->image ?? null )); ?>" width="100" alt="">
                            <?php endif; ?>
                            <h4><a href="<?php echo e(route('event', $item)); ?>"><?php echo e($item->name ?? null); ?></a></h4>
                            <p class="text-secondary">Event Date : <?php echo e($item->event_date ?? null); ?> | Event Time : <?php echo e($item->event_time ?? null); ?></p>
                            <p><?php echo e(Str::limit($item->body ?? null, 100)); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dinkes.bolmongkab\resources\views/home.blade.php ENDPATH**/ ?>