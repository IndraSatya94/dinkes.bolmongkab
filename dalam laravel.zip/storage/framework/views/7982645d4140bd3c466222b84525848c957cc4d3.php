<?php if($recents): ?>
<h3 class="sidebar-title">Recents</h3>
<div class="sidebar-item recent-posts">
    <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post-item clearfix">
        <?php if(Storage::disk('public')->exists($recent->image ?? null)): ?>
        <img src="<?php echo e(Storage::url($recent->image ?? null)); ?>" alt="">
        <?php endif; ?>
        <h4><a href="<?php echo e(route('news', $recent)); ?>"><?php echo e($recent->name); ?></a></h4>
        <time datetime="<?php echo e($recent->created_at); ?>"><?php echo e($recent->created_at); ?></time>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!-- End sidebar recent posts-->
<?php endif; ?><?php /**PATH F:\laragon\www\dispusip\resources\views/layouts/frontend/recent.blade.php ENDPATH**/ ?>