<?php if(isset($categories)): ?>
<div class="offset-top-60">
    <!-- Categories-->
    <h6 class="font-weight-bold">Categories</h6>
    <div class="text-subline"></div>
    <div class="offset-top-20">
        <ul class="list list-marked list-marked-primary">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('category', $category->slug)); ?>"><?php echo e($category->name ?? null); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php endif; ?><?php /**PATH F:\laragon\www\bkd.bolmongkab\resources\views/layouts/category.blade.php ENDPATH**/ ?>