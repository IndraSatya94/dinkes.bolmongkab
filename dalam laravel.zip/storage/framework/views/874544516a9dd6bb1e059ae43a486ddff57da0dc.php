<header id="header" class="fixed-top">
    <div class="container d-flex justify-content-between">
        <div class="d-flex align-items-center">
            <a href="<?php echo e(route('home')); ?>" class="logo mr-2 mt-n2">
                <div class="d-flex justify-content-between">
                    <?php if(Storage::disk('public')->exists($profile->image ?? null)): ?>
                    <img src="<?php echo e(Storage::url($profile->image ?? null)); ?>" alt="" class="img-fluid">
                    <?php endif; ?>
                    <div class="ml-2 text-secondary">
                        <h1 class="h6 font-weight-bolder"><?php echo e($profile->name ?? null); ?></h1>
                        <h6 class="mt-n2">Pemerintah Kabupaten Bolaang Mongondow</h6>
                    </div>
                </div>
            </a>
        </div>
        <?php echo $__env->make('layouts.frontend.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</header><!-- End Header --><?php /**PATH C:\xampp\htdocs\bappeda.bolmongkab\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>