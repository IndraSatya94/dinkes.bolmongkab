<h3 class="sidebar-title">Search</h3>
<div class="sidebar-item search-form">
    <form action="<?php echo e(route('search')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="s" id="s">
        <button type="submit"><i class="icofont-search"></i></button>
    </form>

</div><!-- End sidebar search formn--><?php /**PATH C:\xampp\htdocs\dinkes.bolmongkab\resources\views/layouts/frontend/search.blade.php ENDPATH**/ ?>